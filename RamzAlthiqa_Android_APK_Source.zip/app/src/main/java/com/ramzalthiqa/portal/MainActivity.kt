package com.ramzalthiqa.portal

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

data class BookingAccount(
    val id: String,
    var name: String,
    var company: String,
    var currency: String,
    var username: String,
    var password: String
)

class MainActivity : AppCompatActivity() {

    private val prefsName = "RamzAlthiqaPrefs"
    private val accounts = mutableListOf<BookingAccount>()
    private val webViews = mutableMapOf<String, WebView>()
    private lateinit var webContainer: FrameLayout
    private lateinit var dashboardScroll: ScrollView
    private lateinit var cardsContainer: LinearLayout
    private lateinit var tabsBar: LinearLayout
    private lateinit var urlInput: EditText
    private var activeAccountId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadAccounts()
        buildUI()
    }

    private fun loadAccounts() {
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val savedJson = prefs.getString("accounts_json", null)
        accounts.clear()
        if (savedJson == null) {
            accounts.addAll(
                listOf(
                    BookingAccount("1", "سودانير - جنيه", "Sudanair", "SDG", "RAMZALTHIQAHSDG", ""),
                    BookingAccount("2", "سودانير - دولار", "Sudanair", "USD", "RAMZALTHIQAHUSD", ""),
                    BookingAccount("3", "بدر - جنيه", "Badr", "SDG", "RAMZALTHIQAH", ""),
                    BookingAccount("4", "بدر - دولار", "Badr", "USD", "RAMZALTHIQAHUSD", ""),
                    BookingAccount("5", "تاركو - جنيه", "3tair", "SDG", "RAMZ", ""),
                    BookingAccount("6", "تاركو - دولار", "3tair", "USD", "RAMZ.USD", "")
                )
            )
            saveAccounts()
        } else {
            val arr = JSONArray(savedJson)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                accounts.add(
                    BookingAccount(
                        o.getString("id"),
                        o.getString("name"),
                        o.getString("company"),
                        o.getString("currency"),
                        o.getString("username"),
                        o.optString("password", "")
                    )
                )
            }
        }
    }

    private fun saveAccounts() {
        val arr = JSONArray()
        for (a in accounts) {
            val o = JSONObject()
            o.put("id", a.id)
            o.put("name", a.name)
            o.put("company", a.company)
            o.put("currency", a.currency)
            o.put("username", a.username)
            o.put("password", a.password)
            arr.put(o)
        }
        getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            .edit().putString("accounts_json", arr.toString()).apply()
    }

    private fun buildUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F3F6FB"))
        }

        // Top Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#06172D"))
            setPadding(32, 28, 32, 28)
            gravity = Gravity.CENTER_VERTICAL
        }

        val logoView = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            layoutParams = LinearLayout.LayoutParams(110, 110).apply { marginEnd = 24 }
        }

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleBox.addView(TextView(this).apply {
            text = "رمز الثقة للسفر والسياحة"
            setTextColor(Color.WHITE)
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
        })
        titleBox.addView(TextView(this).apply {
            text = "RAMZ AL-THIQAH • MULTI-SESSION PORTAL"
            setTextColor(Color.parseColor("#F39A24"))
            textSize = 10f
        })

        val homeBtn = Button(this).apply {
            text = "القائمة ☰"
            setBackgroundColor(Color.parseColor("#124B91"))
            setTextColor(Color.WHITE)
            textSize = 12f
            setOnClickListener { showDashboard() }
        }

        header.addView(logoView)
        header.addView(titleBox)
        header.addView(homeBtn)
        root.addView(header)

        // Active Tabs Bar (Horizontal Scroll for instant switching between open sessions)
        val tabsScroll = HorizontalScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0D2748"))
            isHorizontalScrollBarEnabled = false
        }
        tabsBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 10, 16, 10)
        }
        tabsScroll.addView(tabsBar)
        root.addView(tabsScroll)

        // Main Body Frame (Switches between Dashboard and Isolated WebViews)
        val bodyFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        webContainer = FrameLayout(this).apply {
            visibility = View.GONE
        }

        dashboardScroll = ScrollView(this)
        val dashContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 40)
        }

        // URL Config Box
        val urlBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
            setPadding(20, 14, 20, 14)
            gravity = Gravity.CENTER_VERTICAL
        }
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        urlInput = EditText(this).apply {
            hint = "رابط الحجز الموحد https://..."
            setText(prefs.getString("booking_url", "https://"))
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val saveUrlBtn = Button(this).apply {
            text = "حفظ الرابط"
            setBackgroundColor(Color.parseColor("#06172D"))
            setTextColor(Color.WHITE)
            textSize = 12f
            setOnClickListener {
                prefs.edit().putString("booking_url", urlInput.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "تم حفظ رابط الحجز الموحد ✓", Toast.LENGTH_SHORT).show()
            }
        }
        urlBox.addView(urlInput)
        urlBox.addView(saveUrlBtn)
        dashContent.addView(urlBox)

        // Add Account Button
        val addNewBtn = Button(this).apply {
            text = "＋ إضافة شركة أو عملة جديدة"
            setBackgroundColor(Color.parseColor("#F39A24"))
            setTextColor(Color.parseColor("#06172D"))
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 20; bottomMargin = 20 }
            setOnClickListener { showEditDialog(null) }
        }
        dashContent.addView(addNewBtn)

        cardsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        dashContent.addView(cardsContainer)
        dashboardScroll.addView(dashContent)

        bodyFrame.addView(webContainer)
        bodyFrame.addView(dashboardScroll)
        root.addView(bodyFrame)

        setContentView(root)
        renderCards()
    }

    private fun renderCards() {
        cardsContainer.removeAllViews()
        for (acc in accounts) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(Color.WHITE)
                setPadding(24, 22, 24, 22)
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 18 }
            }

            val badge = TextView(this).apply {
                text = "${acc.company}\n${acc.currency}"
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#124B91"))
                setBackgroundColor(Color.parseColor("#EAF1FB"))
                textSize = 11f
                setTypeface(null, Typeface.BOLD)
                setPadding(16, 14, 16, 14)
                layoutParams = LinearLayout.LayoutParams(150, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    marginEnd = 20
                }
            }

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            info.addView(TextView(this).apply {
                text = acc.name
                textSize = 15f
                setTextColor(Color.parseColor("#14243A"))
                setTypeface(null, Typeface.BOLD)
            })
            val status = if (acc.password.isNotEmpty()) "كلمة المرور محفوظة ✓" else "اضغط تعديل لإضافة الباسورد"
            info.addView(TextView(this).apply {
                text = "${acc.username} • $status"
                textSize = 11f
                setTextColor(Color.parseColor("#66758A"))
            })

            val editBtn = Button(this).apply {
                text = "✎"
                textSize = 14f
                setBackgroundColor(Color.parseColor("#EDF2F7"))
                layoutParams = LinearLayout.LayoutParams(100, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    marginEnd = 10
                }
                setOnClickListener { showEditDialog(acc) }
            }

            val openBtn = Button(this).apply {
                text = "دخول ↗"
                textSize = 12f
                setBackgroundColor(Color.parseColor("#124B91"))
                setTextColor(Color.WHITE)
                setTypeface(null, Typeface.BOLD)
                setOnClickListener { openIsolatedSession(acc) }
            }

            card.addView(badge)
            card.addView(info)
            card.addView(editBtn)
            card.addView(openBtn)
            cardsContainer.addView(card)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openIsolatedSession(acc: BookingAccount) {
        val url = urlInput.text.toString().trim()
        if (url.isEmpty() || url == "https://") {
            Toast.makeText(this, "يرجى إدخال رابط الحجز الموحد وحفظه أولاً", Toast.LENGTH_LONG).show()
            return
        }

        // Clean cookies per session switch to ensure 100% isolation
        val cm = CookieManager.getInstance()
        cm.removeAllCookies(null)
        cm.flush()

        var wv = webViews[acc.id]
        if (wv == null) {
            wv = WebView(this).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, pageUrl: String?) {
                        super.onPageFinished(view, pageUrl)
                        injectAutoFill(view, acc)
                    }
                }
            }
            webViews[acc.id] = wv
            webContainer.addView(wv)
            wv.loadUrl(url)
        }

        for ((id, view) in webViews) {
            view.visibility = if (id == acc.id) View.VISIBLE else View.GONE
        }

        activeAccountId = acc.id
        dashboardScroll.visibility = View.GONE
        webContainer.visibility = View.VISIBLE
        renderTabsBar()
    }

    private fun injectAutoFill(view: WebView?, acc: BookingAccount) {
        val js = """
            (function() {
              const inputs = Array.from(document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"])'));
              const passField = document.querySelector('input[type="password"]');
              let userField = document.querySelector('input[name*="user" i], input[id*="user" i], input[name*="login" i]');
              let airlineField = document.querySelector('input[name*="air" i], input[id*="air" i], input[name*="comp" i], input[name*="code" i], select');
              if (!userField && inputs.length > 0) userField = inputs[0];
              if (!airlineField && inputs.length > 2) {
                airlineField = inputs.find(el => el !== userField && el !== passField);
              }
              function fill(el, val) {
                if (!el || !val) return;
                el.value = val;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
              }
              fill(userField, '${acc.username}');
              fill(passField, '${acc.password}');
              fill(airlineField, '${acc.company}');
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun renderTabsBar() {
        tabsBar.removeAllViews()
        for ((id, _) in webViews) {
            val acc = accounts.find { it.id == id } ?: continue
            val isActive = (id == activeAccountId && webContainer.visibility == View.VISIBLE)
            val tabBtn = Button(this).apply {
                text = "${acc.name}  ✕"
                textSize = 11f
                setTextColor(if (isActive) Color.parseColor("#06172D") else Color.WHITE)
                setBackgroundColor(if (isActive) Color.parseColor("#F39A24") else Color.parseColor("#1D4E89"))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = 10 }
                setOnClickListener { openIsolatedSession(acc) }
                setOnLongClickListener {
                    webContainer.removeView(webViews[id])
                    webViews.remove(id)
                    renderTabsBar()
                    if (webViews.isEmpty()) showDashboard()
                    true
                }
            }
            tabsBar.addView(tabBtn)
        }
    }

    private fun showDashboard() {
        webContainer.visibility = View.GONE
        dashboardScroll.visibility = View.VISIBLE
        renderTabsBar()
    }

    private fun showEditDialog(acc: BookingAccount?) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 10)
        }
        val nameIn = EditText(this).apply { hint = "اسم الحساب (مثال: سودانير - جنيه)"; setText(acc?.name ?: "") }
        val compIn = EditText(this).apply { hint = "كود الشركة (Sudanair / Badr / 3tair)"; setText(acc?.company ?: "") }
        val currIn = EditText(this).apply { hint = "العملة (SDG / USD)"; setText(acc?.currency ?: "SDG") }
        val userIn = EditText(this).apply { hint = "اسم المستخدم"; setText(acc?.username ?: "") }
        val passIn = EditText(this).apply {
            hint = "كلمة المرور"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(acc?.password ?: "")
        }

        layout.addView(nameIn); layout.addView(compIn); layout.addView(currIn); layout.addView(userIn); layout.addView(passIn)

        AlertDialog.Builder(this)
            .setTitle(if (acc == null) "إضافة حساب جديد" else "تعديل: ${acc.name}")
            .setView(layout)
            .setPositiveButton("حفظ") { _, _ ->
                if (acc == null) {
                    accounts.add(
                        BookingAccount(
                            System.currentTimeMillis().toString(),
                            nameIn.text.toString(),
                            compIn.text.toString(),
                            currIn.text.toString(),
                            userIn.text.toString(),
                            passIn.text.toString()
                        )
                    )
                } else {
                    acc.name = nameIn.text.toString()
                    acc.company = compIn.text.toString()
                    acc.currency = currIn.text.toString()
                    acc.username = userIn.text.toString()
                    acc.password = passIn.text.toString()
                }
                saveAccounts()
                renderCards()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onBackPressed() {
        if (webContainer.visibility == View.VISIBLE) {
            val wv = webViews[activeAccountId]
            if (wv != null && wv.canGoBack()) {
                wv.goBack()
            } else {
                showDashboard()
            }
        } else {
            super.onBackPressed()
        }
    }
}